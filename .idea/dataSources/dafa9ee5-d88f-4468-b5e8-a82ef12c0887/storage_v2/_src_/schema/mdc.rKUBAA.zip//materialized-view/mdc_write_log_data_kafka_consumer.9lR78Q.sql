CREATE MATERIALIZED VIEW mdc.mdc_write_log_data_kafka_consumer
            TO mdc.mdc_write_log_data
            (
             `write_type` UInt32,
             `device_code` String,
             `device_name` String,
             `device_type_code` String,
             `point_code` String,
             `point_name` String,
             `point_data_type` String,
             `write_value` String,
             `success` UInt32,
             `message` String,
             `username` String,
             `opt_url` String,
             `opt_ip` String,
             `opt_param` String,
             `opt_result` String,
             `req_time` DateTime64(3),
             `resp_time` DateTime64(3),
             `write_time` UInt64
                )
AS
SELECT writeType      AS write_type,
       deviceCode     AS device_code,
       deviceName     AS device_name,
       deviceTypeCode AS device_type_code,
       pointCode      AS point_code,
       pointName      AS point_name,
       pointDataType  AS point_data_type,
       writeValue     AS write_value,
       success        AS success,
       message        AS message,
       username       AS username,
       optUrl         AS opt_url,
       optIp          AS opt_ip,
       optParam       AS opt_param,
       optResult      AS opt_result,
       reqTime        AS req_time,
       respTime       AS resp_time,
       writeTime      AS write_time
FROM mdc.mdc_write_log_data_kafka_engine;

