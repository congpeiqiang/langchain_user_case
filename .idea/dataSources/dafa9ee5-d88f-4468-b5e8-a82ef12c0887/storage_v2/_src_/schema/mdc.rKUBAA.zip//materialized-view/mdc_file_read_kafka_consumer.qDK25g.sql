CREATE MATERIALIZED VIEW mdc.mdc_file_read_kafka_consumer
            TO mdc.mdc_file_read
            (
             `code` String,
             `ip` String,
             `file_name` String,
             `file_time` DateTime64(3),
             `row_no` Int64,
             `file_type` String,
             `comments` String,
             `collection_time` DateTime64(3)
                )
AS
SELECT code           AS code,
       ip             AS ip,
       fileName       AS file_name,
       fileTime       AS file_time,
       rowNo          AS row_no,
       fileType       AS file_type,
       comments       AS comments,
       collectionTime AS collection_time
FROM mdc.mdc_file_read_kafka_engine;

