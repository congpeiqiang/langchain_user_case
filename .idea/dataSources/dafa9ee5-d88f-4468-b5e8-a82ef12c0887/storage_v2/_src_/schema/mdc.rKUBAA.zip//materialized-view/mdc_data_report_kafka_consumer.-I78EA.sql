CREATE MATERIALIZED VIEW mdc.mdc_data_report_kafka_consumer
            TO mdc.mdc_data_report
            (
             `type` String,
             `topic` String,
             `report_ip` String,
             `report_param` String,
             `result_code` Int64,
             `result_msg` String,
             `report_time` DateTime64(3),
             `error_msg` String
                )
AS
SELECT type        AS type,
       topic       AS topic,
       reportIp    AS report_ip,
       reportParam AS report_param,
       resultCode  AS result_code,
       resultMsg   AS result_msg,
       reportTime  AS report_time,
       errorMsg    AS error_msg
FROM mdc.mdc_data_report_kafka_engine;

