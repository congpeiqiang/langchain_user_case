CREATE MATERIALIZED VIEW mdc.mdc_bcr_code_kafka_consumer
            TO mdc.mdc_bcr_code
            (
             `cam_code` String,
             `cam_name` String,
             `cam_ip` String,
             `n_bar_type` UInt32,
             `ppm` Decimal(18, 1),
             `content` String,
             `s_algo_cost` Int16,
             `n_idr_score` UInt32,
             `trigger_time` DateTime64(3),
             `trigger_ts` UInt64,
             `image_url` String
                )
AS
SELECT camCode     AS cam_code,
       camName     AS cam_name,
       camIp       AS cam_ip,
       nBarType    AS n_bar_type,
       ppm         AS ppm,
       content     AS content,
       sAlgoCost   AS s_algo_cost,
       nIdrScore   AS n_idr_score,
       triggerTime AS trigger_time,
       triggerTs   AS trigger_ts,
       imageUrl    AS image_url
FROM mdc.mdc_bcr_code_kafka_engine;

