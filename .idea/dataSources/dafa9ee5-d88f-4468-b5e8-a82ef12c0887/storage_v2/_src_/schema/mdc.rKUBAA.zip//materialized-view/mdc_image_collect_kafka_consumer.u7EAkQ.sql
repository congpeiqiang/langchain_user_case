CREATE MATERIALIZED VIEW mdc.mdc_image_collect_kafka_consumer
            TO mdc.mdc_image_collect
            (
             `folder_code` String,
             `topic` String,
             `folder` String,
             `sub_folder` String,
             `name` String,
             `image_type` String,
             `url` String,
             `ip` String,
             `create_time` DateTime64(3),
             `collection_time` DateTime64(3)
                )
AS
SELECT folderCode     AS folder_code,
       topic          AS topic,
       folder         AS folder,
       name           AS name,
       subFolder      AS sub_folder,
       url            AS url,
       imageType      AS image_type,
       ip             AS ip,
       createTime     AS create_time,
       collectionTime AS collection_time
FROM mdc.mdc_image_collect_kafka_engine;

