CREATE MATERIALIZED VIEW mdc.mdc_job_blocked_kafka_consumer
            TO mdc.mdc_job_blocked
            (
             `trigger_id` Int64,
             `next_fire_time` DateTime64(3),
             `previous_fire_time` DateTime64(3),
             `start_time` DateTime64(3),
             `mis_fire` Int32,
             `collection_time` DateTime64(3)
                )
AS
SELECT triggerId        AS trigger_id,
       nextFireTime     AS next_fire_time,
       previousFireTime AS previous_fire_time,
       startTime        AS start_time,
       misFire          AS mis_fire,
       collectionTime   AS collection_time
FROM mdc.mdc_job_blocked_kafka_engine;

