CREATE MATERIALIZED VIEW mdc.mdc_analysis_kafka_consumer
            TO mdc.mdc_analysis
            (
             `device_code` String,
             `device_name` String,
             `device_type_code` String,
             `device_type_name` String,
             `device_ip` String,
             `device_port` UInt32,
             `protocol_type` String,
             `protocol_params` String,
             `point_code` String,
             `point_name` String,
             `point_address` String,
             `point_type` UInt8,
             `point_data_type` String,
             `point_byte_length` UInt16,
             `point_value` String,
             `point_units` String,
             `collection_time` String,
             `collection_frequency` String,
             `topic` String,
             `vocational_param` String,
             `username` String
                )
AS
SELECT *
FROM mdc.mdc_analysis_kafka_engine;

