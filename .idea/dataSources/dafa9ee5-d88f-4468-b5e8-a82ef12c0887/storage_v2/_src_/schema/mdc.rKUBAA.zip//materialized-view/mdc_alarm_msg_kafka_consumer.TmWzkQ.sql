CREATE MATERIALIZED VIEW mdc.mdc_alarm_msg_kafka_consumer
            TO mdc.mdc_alarm_msg
            (
             `code` String,
             `name` String,
             `ip` String,
             `state` UInt8,
             `message` String,
             `report_time` DateTime64(3),
             `report_ts` UInt64
                )
AS
SELECT code       AS code,
       name       AS name,
       ip         AS ip,
       state      AS state,
       message    AS message,
       reportTime AS report_time,
       reportTs   AS report_ts
FROM mdc.mdc_alarm_msg_kafka_engine;

