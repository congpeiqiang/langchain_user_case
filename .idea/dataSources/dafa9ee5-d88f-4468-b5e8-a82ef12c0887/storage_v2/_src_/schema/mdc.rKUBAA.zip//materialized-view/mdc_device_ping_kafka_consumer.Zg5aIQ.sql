CREATE MATERIALIZED VIEW mdc.mdc_device_ping_kafka_consumer
            TO mdc.mdc_device_ping
            (
             `deleted` UInt8,
             `detected_time` String,
             `device_code` String,
             `device_name` String,
             `device_type_code` String,
             `device_type_name` String,
             `ip` String,
             `response_time` Int32
                )
AS
SELECT deleted        AS deleted,
       detectedTime   AS detected_time,
       deviceCode     AS device_code,
       deviceName     AS device_name,
       deviceTypeCode AS device_type_code,
       deviceTypeName AS device_type_name,
       ip             AS ip,
       responseTime   AS response_time
FROM mdc.mdc_device_ping_kafka_engine;

