CREATE MATERIALIZED VIEW mdc.mdc_share_collect_kafka_consumer
            TO mdc.mdc_share_collect
            (
             `code` String,
             `name` String,
             `type` String,
             `label` String,
             `ip` String,
             `data` String,
             `ts` UInt64,
             `time` DateTime64(3)
                )
AS
SELECT code  AS code,
       name  AS name,
       label AS label,
       type  AS type,
       ip    AS ip,
       data  AS data,
       ts    AS ts,
       time  AS time
FROM mdc.mdc_share_collect_kafka_engine;

