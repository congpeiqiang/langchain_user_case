CREATE MATERIALIZED VIEW mdc.mdc_collect_log_data_kafka_consumer
            TO mdc.mdc_collect_log_data
            (
             `trigger_id` Int64,
             `app` String,
             `host` String,
             `node` String,
             `ip` String,
             `level` String,
             `pid` String,
             `class_name` String,
             `message` String,
             `stack_trace` String,
             `thread` String,
             `timestamp` DateTime64(3)
                )
AS
SELECT triggerId  AS trigger_id,
       app        AS app,
       host       AS host,
       node       AS node,
       ip         AS ip,
       level      AS level,
       pid        AS pid,
       className  AS class_name,
       message    AS message,
       stackTrace AS stack_trace,
       thread     AS thread,
       timestamp  AS timestamp
FROM mdc.mdc_collect_log_data_kafka_engine;

