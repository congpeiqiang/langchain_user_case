CREATE MATERIALIZED VIEW mdc.mdc_pulled_crystal_record_data_kafka_consumer
            TO mdc.mdc_pulled_crystal_record_data
            (
             `device_code` String,
             `ip` String,
             `time` DateTime64(3),
             `content` String,
             `value` String,
             `color` String,
             `mdc_uuid` String
                )
AS
SELECT *
FROM mdc.mdc_pulled_crystal_record_data_kafka_engine;

